<?php

	$hostname = "localhost";
	$username = "root";
	$password = "";
	$dbname = "first_database";
	
	$connect = mysqli_connect($hostname, $username, $password, $dbname)
				OR DIE ("Connection failed");

				
?>