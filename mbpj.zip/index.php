<!DOCTYPE html>
<html>
	<head>
		<title> Lab Exercise Chapter 12 </title>
	</head>
	<body>
		<h1> CSC318 Survey </h1>
		<form action="student_info.php" method="GET">
		<fieldset>
			<legend> Student Information </legend>
			Student ID 		:<br>
			<input type="text" name="StudId"><br>
			Full Name		:<br>
			<input type="text" name="name"><br>
			Email			:<br>
			<input type="email" name="email"><br>
			Phone			:<br>
			<input type="number" name="phone"><br><br>
		</fieldset>
		<fieldset>
			<legend> Reference </legend>
			What kind of reference do you consider the most useful?<br>
			<input type="radio" name="ref" value="textbooks">Text Books
			<input type="radio" name="ref" value="slides">Lecture Slides
			<input type="radio" name="ref" value="manual">Manual
			<br>
		</fieldset>
		<fieldset>
			<legend> Local Server </legend>
			Which local server do you enjoy using?<br>
			<select name="server">
				<option value="choose" selected>Choose server...</option>
				<option value="xampp">XAMPP Server</option>
				<option value="wamp">WAMP Server</option>
			</select>
		</fieldset><br>
		<input type="submit" value="Submit">
		</form>
	</body>
</html>
				

	